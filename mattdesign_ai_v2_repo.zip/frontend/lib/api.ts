export type GeneratePayload = {
  prompt: string;
  project_name?: string;
  target?: string;
  style?: string;
  selected_agents?: string[];
  one_click?: boolean;
  auto_improve?: boolean;
};

const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000';

export async function generateProject(payload: GeneratePayload) {
  const res = await fetch(`${API_BASE}/generate`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    throw new Error(`API error: ${res.status}`);
  }

  return res.json();
}

export async function fetchProjects() {
  const res = await fetch(`${API_BASE}/projects`, { cache: 'no-store' });
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  return res.json();
}
