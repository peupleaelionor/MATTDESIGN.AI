from __future__ import annotations

from typing import Any

from ..providers.factory import get_provider


SYSTEM = 'You are the Design DNA engine. Create a coherent visual identity with palette, typography, spacing, and mood.'


def run_design_dna(context: dict[str, Any]) -> dict[str, Any]:
    provider = get_provider()
    prompt = context.get("prompt", "")
    brief = context.get("brief", {})
    design_dna = context.get("design_dna", {})
    previous_memory = context.get("memory", {})

    # Optional provider call. The fallback provider makes this repo runnable offline.
    try:
        result = provider.complete(
            SYSTEM,
            f"Prompt: {prompt}\nBrief: {brief}\nDesign DNA: {design_dna}\nMemory: {previous_memory}",
            temperature=0.2,
        )
        provider_content = result.content
    except Exception as exc:
        provider_content = f"provider_error={str(exc)}"

    return {
        "agent": "design_dna",
        "provider": getattr(provider, "name", "unknown"),
        "content": provider_content,
        "design_dna": {
        "palette": context.get("style_palette") or ["#0B0B0B", "#F5F5F5", "#6366F1", "#8B5CF6"],
        "typography": ["Inter", "Satoshi", "system-ui"],
        "spacing": "8px scale",
        "radius": "16px",
        "visual_style": context.get("style") or "minimal premium tech"
    },
    }
