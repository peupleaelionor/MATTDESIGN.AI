# Architecture

## Flow
User brief -> Director -> Strategist -> Design DNA -> UI -> Assets -> Copy -> Builder -> Critic -> Optimizer -> Memory -> Result

## Why this works
- Director gets the intent right
- Strategist protects conversion
- Design DNA keeps coherence
- UI shapes the site structure
- Assets create visual richness
- Copy makes the message sell
- Builder turns concept into implementation
- Critic catches weak output
- Optimizer raises the quality
- Memory accumulates patterns over time

## One-click generation
The frontend sends a single request to the backend. The backend runs the full chain and returns:
- summary
- design DNA
- structure
- assets
- copy
- critic review
- optimization notes
- memory snapshot

## Free-first defaults
- Fallback provider for offline usage
- Optional Ollama integration
- Optional OpenAI / Anthropic providers
- JSON-based memory
