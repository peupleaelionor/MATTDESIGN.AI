import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        bg: '#060816',
        panel: '#0E1324',
        text: '#F7F8FC',
        muted: '#9AA4BF',
        accent: '#6366F1',
        accent2: '#8B5CF6',
        border: 'rgba(255,255,255,0.08)',
      },
      boxShadow: {
        glow: '0 0 0 1px rgba(99,102,241,0.22), 0 20px 80px rgba(99,102,241,0.18)',
      },
    },
  },
  plugins: [],
};
export default config;
