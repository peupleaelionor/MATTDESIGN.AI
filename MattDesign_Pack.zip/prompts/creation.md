Crée une image professionnelle avec une direction artistique claire, une composition forte, des détails propres, une lumière crédible, des textures riches et une finition prête pour web, print ou social.

Contraintes :
- conserver l’intention du brief
- produire plusieurs variantes si nécessaire
- éviter les artefacts
- éviter les bords sales
- éviter les incohérences de perspective
- optimiser la lisibilité du sujet
- préparer un export final propre

Étapes recommandées :
1. analyser le brief
2. sélectionner les références utiles
3. générer les variantes
4. comparer les résultats
5. retoucher si nécessaire
6. détacher le fond si nécessaire
7. upscale en dernier
8. exporter selon le support cible
