from __future__ import annotations

from typing import Any

from ..providers.factory import get_provider


SYSTEM = 'You are the UI/UX agent. Generate a premium site structure with a clear information architecture and modern section order.'


def run_ui(context: dict[str, Any]) -> dict[str, Any]:
    provider = get_provider()
    prompt = context.get("prompt", "")
    brief = context.get("brief", {})
    design_dna = context.get("design_dna", {})
    previous_memory = context.get("memory", {})

    # Optional provider call. The fallback provider makes this repo runnable offline.
    try:
        result = provider.complete(
            SYSTEM,
            f"Prompt: {prompt}\nBrief: {brief}\nDesign DNA: {design_dna}\nMemory: {previous_memory}",
            temperature=0.2,
        )
        provider_content = result.content
    except Exception as exc:
        provider_content = f"provider_error={str(exc)}"

    return {
        "agent": "ui",
        "provider": getattr(provider, "name", "unknown"),
        "content": provider_content,
        "structure": {
        "pages": ["home"],
        "sections": [
            "hero",
            "social_proof",
            "features",
            "workflow",
            "assets_gallery",
            "faq",
            "final_cta",
            "footer"
        ],
        "mobile_first": True
    },
    }
