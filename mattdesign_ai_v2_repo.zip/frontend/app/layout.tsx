import './globals.css';

export const metadata = {
  title: 'MattDESIGN.AI v2',
  description: 'Autonomous design system for premium websites and assets',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
