from __future__ import annotations

from ..settings import settings
from .base import BaseProvider
from .fallback import FallbackProvider

try:
    from .ollama import OllamaProvider
except Exception:  # pragma: no cover
    OllamaProvider = None  # type: ignore


def get_provider() -> BaseProvider:
    provider = settings.default_model_provider.lower().strip()
    if provider == "ollama" and OllamaProvider is not None:
        return OllamaProvider(base_url=settings.ollama_base_url)
    return FallbackProvider()
