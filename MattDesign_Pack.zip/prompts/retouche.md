Retoucher l’image sans détruire le caractère original.

Contraintes :
- conserver le style
- conserver la palette
- corriger uniquement ce qui gêne
- utiliser un masque si nécessaire
- nettoyer les défauts
- améliorer la lisibilité
- préserver l’identité visuelle
- upscale seulement après validation

Étapes recommandées :
1. ouvrir l’image source
2. repérer les zones à corriger
3. créer ou affiner le masque
4. retoucher localement
5. vérifier les bords
6. faire un export test
7. lancer l’upscale final
