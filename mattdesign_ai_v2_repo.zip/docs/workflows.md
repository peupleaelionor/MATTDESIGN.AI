# Workflows

## Full generation
1. Write a brief
2. Select agents
3. Press Generate
4. Inspect output
5. Re-run with improved brief if needed

## Quality loop
1. Generate version 1
2. Critic scores it
3. If score < threshold, optimizer improves it
4. Save to memory
5. Reuse best patterns on the next project

## Prompt discipline
- Give the project name
- Specify the target
- Specify the style
- Mention references if relevant
- Ask for premium, modern, coherent results
