from __future__ import annotations

import json
from .base import BaseProvider, ProviderResult


class FallbackProvider(BaseProvider):
    name = "fallback"

    def complete(self, system: str, user: str, temperature: float = 0.2) -> ProviderResult:
        payload = {
            "provider": self.name,
            "system_hint": system[:180],
            "user_hint": user[:180],
            "temperature": temperature,
        }
        return ProviderResult(content=json.dumps(payload, ensure_ascii=False), metadata=payload)
