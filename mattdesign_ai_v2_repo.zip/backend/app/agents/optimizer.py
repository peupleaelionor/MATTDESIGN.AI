from __future__ import annotations

from typing import Any

from ..providers.factory import get_provider


SYSTEM = 'You are the Optimizer agent. Fix weak points from the critic and produce a stronger final version.'


def run_optimizer(context: dict[str, Any]) -> dict[str, Any]:
    provider = get_provider()
    prompt = context.get("prompt", "")
    brief = context.get("brief", {})
    design_dna = context.get("design_dna", {})
    previous_memory = context.get("memory", {})

    # Optional provider call. The fallback provider makes this repo runnable offline.
    try:
        result = provider.complete(
            SYSTEM,
            f"Prompt: {prompt}\nBrief: {brief}\nDesign DNA: {design_dna}\nMemory: {previous_memory}",
            temperature=0.2,
        )
        provider_content = result.content
    except Exception as exc:
        provider_content = f"provider_error={str(exc)}"

    return {
        "agent": "optimizer",
        "provider": getattr(provider, "name", "unknown"),
        "content": provider_content,
        "optimizer": {
        "improvements": [
            "tighten hero copy",
            "reduce clutter",
            "increase visual hierarchy",
            "enforce a single visual style"
        ],
        "applied": True
    },
    }
