
from __future__ import annotations

from typing import Any

from .agents.director import run_director
from .agents.strategist import run_strategist
from .agents.design_dna import run_design_dna
from .agents.ui import run_ui
from .agents.assets import run_assets
from .agents.copy import run_copy
from .agents.builder import run_builder
from .agents.critic import run_critic
from .agents.optimizer import run_optimizer
from .agents.memory import run_memory
from .memory import create_memory_snapshot


def _project_name_from_prompt(prompt: str, fallback: str | None = None) -> str:
    if fallback and fallback.strip():
        return fallback.strip()
    cleaned = " ".join(prompt.strip().split())
    if len(cleaned) <= 40:
        return cleaned[:40]
    return cleaned[:40].rsplit(" ", 1)[0] or cleaned[:40]


def run_project(payload: dict[str, Any]) -> dict[str, Any]:
    prompt = payload.get("prompt", "")
    project_name = _project_name_from_prompt(prompt, payload.get("project_name"))

    base_context: dict[str, Any] = {
        "prompt": prompt,
        "target": payload.get("target", "website"),
        "project_name": project_name,
        "style": payload.get("style", "minimal premium tech"),
        "memory": create_memory_snapshot(),
        "style_palette": payload.get("style_palette"),
        "brief": payload,
    }

    run_log: list[dict[str, Any]] = []

    director = run_director(base_context)
    run_log.append({"agent": "director", "status": "done"})

    strategist = run_strategist({**base_context, **director})
    run_log.append({"agent": "strategist", "status": "done"})

    design_dna = run_design_dna({**base_context, **director, **strategist})
    run_log.append({"agent": "design_dna", "status": "done"})

    ui = run_ui({**base_context, **director, **strategist, **design_dna})
    run_log.append({"agent": "ui", "status": "done"})

    assets = run_assets({**base_context, **director, **strategist, **design_dna, **ui})
    run_log.append({"agent": "assets", "status": "done"})

    copy = run_copy({**base_context, **director, **strategist, **design_dna, **ui, **assets})
    run_log.append({"agent": "copy", "status": "done"})

    builder = run_builder({**base_context, **director, **strategist, **design_dna, **ui, **assets, **copy})
    run_log.append({"agent": "builder", "status": "done"})

    critic = run_critic({**base_context, **director, **strategist, **design_dna, **ui, **assets, **copy, **builder})
    run_log.append({"agent": "critic", "status": "done"})

    optimizer = {"optimizer": {"improvements": [], "applied": False}}
    if payload.get("auto_improve", True) and critic["critic"]["score"] < 8.0:
        optimizer = run_optimizer({
            **base_context,
            **director,
            **strategist,
            **design_dna,
            **ui,
            **assets,
            **copy,
            **builder,
            **critic,
        })
        run_log.append({"agent": "optimizer", "status": "done"})

    memory = run_memory({
        "project_name": project_name,
        "prompt": prompt,
        "summary": f"{project_name} — {design_dna['design_dna']['visual_style']}",
        "design_dna": design_dna,
        "ui": ui,
        "assets": assets,
        "copy": copy,
        "builder": builder,
        "critic": critic,
        "optimizer": optimizer,
    })
    run_log.append({"agent": "memory", "status": "done"})

    score = critic["critic"]["score"]
    if optimizer.get("optimizer", {}).get("applied"):
        score = min(9.6, score + 0.4)

    result = {
        "project_name": project_name,
        "summary": f"{project_name} — {design_dna['design_dna']['visual_style']}",
        "score": score,
        "design_dna": design_dna,
        "structure": ui,
        "assets": assets,
        "copy": copy,
        "builder_output": builder,
        "critic": critic,
        "optimizer": optimizer,
        "memory": memory,
    }
    return {"result": result, "run_log": run_log}
