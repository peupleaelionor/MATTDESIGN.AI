# MattDESIGN.AI — Premium AI Designer

> Le designer IA premium pour créer des sites qui inspirent confiance.

## 🌐 Pages disponibles

| Page | URL | Description |
|------|-----|-------------|
| Landing Page | `index.html` | Page principale complète |
| Dashboard | `dashboard.html` | Interface produit SaaS |
| Brand Guide | `brand.html` | Mini guide de marque |

## ✅ Fonctionnalités implémentées

### Landing Page (`index.html`)
- **Nav fixe** avec scroll detection + menu mobile hamburger
- **Hero section** avec mockup dashboard animé, floating cards, typewriter effect
- **Section problème** — 4 problèmes clés avec hover animations
- **Section solution** — Pipeline visuel 5 étapes
- **Section fonctionnalités** — 8 cards premium avec feature-card-large grid
- **Section "How it works"** — 5 étapes avec icônes et connecteurs
- **Section exemples** — 4 mockups de sites (SaaS, Agence, App, Creator)
- **Section tarifs** — 3 plans (Launch, SaaS Starter, Agency Kit) + trust badges
- **Section différenciation** — Comparatif + QA Score card avec barres animées
- **FAQ accordéon** — 5 questions avec animation
- **CTA final** — Section de conversion
- **Footer complet** — Logo, liens, social, badges
- **Modal démo** — Overlay smooth

### Dashboard (`dashboard.html`)
- **Sidebar** — Nav complète avec 9 vues, plan indicator, user profile
- **8 vues navigables** :
  - Dashboard principal (stats, projets récents, widgets)
  - Nouveau projet (formulaire, sélection style/couleur, DNA preview live)
  - Génération en cours (pipeline agents, timer live, log en direct)
  - Brand DNA (palette, typo, personnalité, voix)
  - Asset Gallery (grid filtrable, légalité)
  - Export Center (GitHub, Framer, Figma, ZIP)
  - Paramètres (profil, plan, usage)
- **Timer de génération** animé en temps réel
- **Log de génération** avec updates progressives
- **Preview DNA** interactive (change selon les inputs)

### Brand Guide (`brand.html`)
- Table des matières avec ancres
- Identité de marque complète
- Showcase logo (horizontal, icône, favicon, light/dark)
- Anatomie du logo documentée
- Règles d'espace de protection
- Palette de couleurs complète (10 couleurs)
- Dégradés officiels
- Échelle typographique
- Composants UI documentés (boutons, badges, cards)
- Voix & Ton (faire / éviter)
- 6 règles "À ne pas faire"

### Assets SVG (`assets/`)
- `logo.svg` — Logo horizontal principal
- `logo-icon.svg` — Icône seule avec fond arrondi
- `favicon.svg` — Favicon 32×32

## 🎨 Design System

### Couleurs
| Token | Valeur | Usage |
|-------|--------|-------|
| `--bg-deep` | `#08090D` | Fond le plus sombre |
| `--bg-base` | `#0B0D12` | Fond principal |
| `--bg-surface` | `#11131A` | Surfaces, cards |
| `--accent-violet` | `#6366F1` | CTA, accents primaires |
| `--accent-gold` | `#D6B36A` | Accents premium |
| `--text-primary` | `#F6F4EF` | Texte principal |

### Typographies
- **Inter** — Police principale (300–800)
- **JetBrains Mono** — Code, données techniques

### Fichiers CSS
- `css/design-system.css` — Tokens, utilities, reset, composants de base
- `css/landing.css` — Styles landing page
- `css/dashboard.css` — Styles dashboard
- `css/brand.css` — Styles brand guide

### Fichiers JS
- `js/landing.js` — Nav, reveal, FAQ, modal, typewriter, tilt effect
- `js/dashboard.js` — Navigation vues, timer, log, preview DNA

## 🚀 Prochaines étapes recommandées

1. **Backend** — Intégrer une vraie API d'IA pour la génération
2. **Auth** — Système d'authentification utilisateur
3. **Persistance** — Sauvegarder projets via l'API RESTful
4. **Animations** — Ajouter GSAP pour les transitions entre vues
5. **Export réel** — Implémenter la génération de code téléchargeable
6. **Blog** — Section articles / changelog
7. **Onboarding** — Flow guidé pour les nouveaux utilisateurs
8. **Dark/Light mode** — Toggle de thème

## 📁 Structure du projet

```
/
├── index.html           # Landing page
├── dashboard.html       # Dashboard produit
├── brand.html           # Mini brand guide
├── css/
│   ├── design-system.css
│   ├── landing.css
│   ├── dashboard.css
│   └── brand.css
├── js/
│   ├── landing.js
│   └── dashboard.js
├── assets/
│   ├── logo.svg
│   ├── logo-icon.svg
│   └── favicon.svg
└── README.md
```

## 💡 Qualité & Standards

- **Responsive** : Mobile-first, breakpoints 768px / 1024px / 1200px
- **Accessibilité** : aria-labels, focus-visible, contrastes WCAG AA
- **Performance** : CDN fonts, SVG optimisés, CSS variables
- **Code** : Sémantique HTML5, CSS custom properties, JS vanilla propre
- **Design** : Inspiré de Linear, Vercel, Framer, Apple, Stripe

---

*MattDESIGN.AI — © 2026 — Tous droits réservés*
