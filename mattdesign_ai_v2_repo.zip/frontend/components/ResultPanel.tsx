'use client';

type Props = {
  data: any;
};

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-3xl border border-white/10 bg-white/5 p-5">
      <h3 className="mb-3 text-lg font-semibold">{title}</h3>
      {children}
    </section>
  );
}

export function ResultPanel({ data }: Props) {
  if (!data) {
    return (
      <div className="rounded-3xl border border-dashed border-white/15 bg-black/20 p-6 text-sm text-slate-400">
        Your generated project will appear here.
      </div>
    );
  }

  const result = data.result ?? data;

  return (
    <div className="grid gap-4">
      <Section title="Overview">
        <div className="grid gap-2 text-sm text-slate-300">
          <div><span className="text-slate-500">Project:</span> {result.project_name}</div>
          <div><span className="text-slate-500">Score:</span> {String(result.score)}</div>
          <div><span className="text-slate-500">Summary:</span> {result.summary}</div>
        </div>
      </Section>

      <Section title="Brand DNA">
        <pre className="overflow-auto rounded-2xl bg-black/30 p-4 text-xs text-slate-200">
          {JSON.stringify(result.design_dna?.design_dna ?? result.design_dna, null, 2)}
        </pre>
      </Section>

      <Section title="Structure">
        <pre className="overflow-auto rounded-2xl bg-black/30 p-4 text-xs text-slate-200">
          {JSON.stringify(result.structure?.structure ?? result.structure, null, 2)}
        </pre>
      </Section>

      <Section title="Assets">
        <div className="grid gap-2 text-sm text-slate-300">
          {(result.assets?.assets ?? result.assets ?? []).map((asset: any) => (
            <div key={asset.name} className="rounded-2xl border border-white/10 bg-black/20 p-3">
              <div className="font-medium text-white">{asset.name}</div>
              <div className="text-slate-400">{asset.purpose}</div>
              <div className="mt-2 text-xs text-slate-500">{asset.prompt}</div>
            </div>
          ))}
        </div>
      </Section>

      <Section title="Copy">
        <pre className="overflow-auto rounded-2xl bg-black/30 p-4 text-xs text-slate-200">
          {JSON.stringify(result.copy?.copy ?? result.copy, null, 2)}
        </pre>
      </Section>

      <Section title="Critic / Optimizer">
        <pre className="overflow-auto rounded-2xl bg-black/30 p-4 text-xs text-slate-200">
          {JSON.stringify({ critic: result.critic, optimizer: result.optimizer }, null, 2)}
        </pre>
      </Section>

      <Section title="Run Log">
        <pre className="overflow-auto rounded-2xl bg-black/30 p-4 text-xs text-slate-200">
          {JSON.stringify(data.run_log ?? [], null, 2)}
        </pre>
      </Section>
    </div>
  );
}
