from __future__ import annotations

from typing import Any

from ..memory import now_iso, remember_project


def run_memory(context: dict[str, Any]) -> dict[str, Any]:
    design = context["design_dna"]["design_dna"]
    ui = context["ui"]["structure"]
    assets = context["assets"]["assets"]
    copy = context["copy"]["copy"]
    critic = context["critic"]["critic"]
    optimizer = context["optimizer"]

    record = {
        "name": context["project_name"],
        "prompt": context["prompt"],
        "summary": context["summary"],
        "score": critic["score"],
        "style": design["visual_style"],
        "colors": design["palette"],
        "components": ui["sections"],
        "assets": [asset["name"] for asset in assets],
        "created_at": now_iso(),
        "result": {
            "design_dna": context["design_dna"],
            "structure": context["ui"],
            "assets": context["assets"],
            "copy": context["copy"],
            "builder_output": context["builder"],
            "critic": context["critic"],
            "optimizer": optimizer,
        },
    }
    memory = remember_project(record)
    return {
        "memory": {
            "saved": True,
            "record_name": record["name"],
            "path": "backend/data/projects.json",
            "count": len(memory.get("projects", [])),
        }
    }
