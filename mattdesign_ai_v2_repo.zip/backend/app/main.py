from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .engine import run_project
from .memory import load_memory
from .models import ProjectRequest, ProjectResponse
from .settings import settings

app = FastAPI(title=settings.app_name, version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health() -> dict[str, str]:
    return {"ok": "true", "name": settings.app_name}


@app.get("/agents")
def agents() -> dict[str, list[str]]:
    return {
        "agents": [
            "director",
            "strategist",
            "design_dna",
            "ui",
            "assets",
            "copy",
            "builder",
            "critic",
            "optimizer",
            "memory",
        ]
    }


@app.get("/projects")
def projects() -> dict:
    return load_memory()


@app.post("/generate", response_model=ProjectResponse)
def generate(request: ProjectRequest) -> ProjectResponse:
    output = run_project(request.model_dump())
    result = output["result"]
    return ProjectResponse(
        ok=True,
        project_name=result["project_name"],
        summary=result["summary"],
        score=result["score"],
        design_dna=result["design_dna"],
        structure=result["structure"],
        assets=result["assets"]["assets"],
        copy=result["copy"]["copy"],
        builder_output=result["builder_output"]["builder_output"],
        critic=result["critic"]["critic"],
        optimizer=result["optimizer"],
        memory=result["memory"],
        result=result,
        run_log=output["run_log"],
    )
