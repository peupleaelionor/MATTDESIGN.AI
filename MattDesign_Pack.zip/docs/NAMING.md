# Nommage MattDesign

## Dossiers
- `assets/raw` : originaux entrants
- `assets/refs` : références visuelles
- `assets/masks` : masques et détourage
- `assets/variants` : variantes intermédiaires
- `assets/exports` : fichiers finaux
- `assets/prompts` : prompts archivés

## Convention
### Fichiers bruts
`YYYYMMDD_client_projet_sujet_v001.ext`

### Références
`style_source_theme.ext`

### Masques
`nomfichier_mask.ext`

### Variantes
`nomfichier_a.ext`, `nomfichier_b.ext`, `nomfichier_c.ext`

### Exports
`nomfichier_final_4k_web.webp`
`nomfichier_final_print.tif`
`nomfichier_final_social_1080x1350.jpg`

## Règle
Aucun original n’est modifié directement.
