'use client';

import { useEffect, useMemo, useState } from 'react';
import { generateProject, fetchProjects } from '@/lib/api';
import { ControlPanel } from '@/components/ControlPanel';
import { ResultPanel } from '@/components/ResultPanel';
import { ProjectHistory } from '@/components/ProjectHistory';

export default function Page() {
  const [prompt, setPrompt] = useState('Build a premium AI SaaS landing page with dark minimal design, strong CTA, and high-end assets.');
  const [projectName, setProjectName] = useState('MattDESIGN.AI');
  const [style, setStyle] = useState('minimal premium tech');
  const [target, setTarget] = useState('website');
  const [oneClick, setOneClick] = useState(true);
  const [autoImprove, setAutoImprove] = useState(true);
  const [selectedAgents, setSelectedAgents] = useState<string[]>([
    'director',
    'strategist',
    'design_dna',
    'ui',
    'assets',
    'copy',
    'builder',
    'critic',
    'optimizer',
    'memory',
  ]);
  const [result, setResult] = useState<any>(null);
  const [projects, setProjects] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const toggleAgent = (agent: string) => {
    setSelectedAgents((current) =>
      current.includes(agent) ? current.filter((item) => item !== agent) : [...current, agent]
    );
  };

  const loadMemory = async () => {
    try {
      const data = await fetchProjects();
      setProjects(data.projects || []);
    } catch {
      setProjects([]);
    }
  };

  useEffect(() => {
    loadMemory();
  }, []);

  const canGenerate = useMemo(() => prompt.trim().length > 0, [prompt]);

  const onGenerate = async () => {
    if (!canGenerate) return;
    setLoading(true);
    setError('');
    try {
      const data = await generateProject({
        prompt,
        project_name: projectName,
        target,
        style,
        selected_agents: selectedAgents as any,
        one_click: oneClick,
        auto_improve: autoImprove,
      });
      setResult(data);
      await loadMemory();
    } catch (err: any) {
      setError(err?.message || 'Generation failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="mx-auto flex min-h-screen max-w-7xl flex-col gap-6 p-4 md:p-8">
      <div className="grid gap-6 lg:grid-cols-[1.05fr_0.95fr]">
        <ControlPanel
          prompt={prompt}
          setPrompt={setPrompt}
          projectName={projectName}
          setProjectName={setProjectName}
          style={style}
          setStyle={setStyle}
          target={target}
          setTarget={setTarget}
          oneClick={oneClick}
          setOneClick={setOneClick}
          autoImprove={autoImprove}
          setAutoImprove={setAutoImprove}
          selectedAgents={selectedAgents}
          toggleAgent={toggleAgent}
          onGenerate={onGenerate}
          loading={loading}
        />

        <div className="grid gap-4">
          {error && (
            <div className="rounded-3xl border border-red-400/30 bg-red-500/10 p-4 text-sm text-red-200">
              {error}
            </div>
          )}
          <ResultPanel data={result} />
        </div>
      </div>

      <ProjectHistory projects={projects} />

      <footer className="pb-4 text-center text-xs text-slate-500">
        Free-first design engine · multi-agent · memory · critic loop · one-click generation
      </footer>
    </main>
  );
}
