from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .settings import settings


def _memory_file() -> Path:
    path = Path(settings.memory_path)
    if not path.is_absolute():
        path = Path(__file__).resolve().parents[1] / path
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.write_text(json.dumps({"projects": []}, indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def load_memory() -> dict[str, Any]:
    return json.loads(_memory_file().read_text(encoding="utf-8"))


def save_memory(payload: dict[str, Any]) -> dict[str, Any]:
    _memory_file().write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    return payload


def remember_project(record: dict[str, Any]) -> dict[str, Any]:
    memory = load_memory()
    memory.setdefault("projects", [])
    memory["projects"].insert(0, record)
    memory["projects"] = memory["projects"][:100]
    return save_memory(memory)


def create_memory_snapshot() -> dict[str, Any]:
    memory = load_memory()
    return {
        "count": len(memory.get("projects", [])),
        "latest": memory.get("projects", [None])[0],
        "path": str(_memory_file()),
    }


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()
