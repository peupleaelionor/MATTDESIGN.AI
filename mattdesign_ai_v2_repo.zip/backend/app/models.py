
from typing import Any, Optional, Literal
from pydantic import BaseModel, Field


AgentName = Literal[
    "director",
    "strategist",
    "design_dna",
    "ui",
    "assets",
    "copy",
    "builder",
    "critic",
    "optimizer",
    "memory",
]


class ProjectRequest(BaseModel):
    prompt: str = Field(..., min_length=3)
    project_name: Optional[str] = None
    target: Optional[str] = "website"
    style: Optional[str] = "minimal premium tech"
    selected_agents: list[AgentName] = Field(default_factory=lambda: [
        "director",
        "strategist",
        "design_dna",
        "ui",
        "assets",
        "copy",
        "builder",
        "critic",
        "optimizer",
        "memory",
    ])
    one_click: bool = True
    auto_improve: bool = True


class ProjectResponse(BaseModel):
    ok: bool = True
    project_name: str
    summary: str
    score: float
    design_dna: dict[str, Any]
    structure: dict[str, Any]
    assets: list[dict[str, Any]]
    copy: dict[str, Any]
    builder_output: dict[str, Any]
    critic: dict[str, Any]
    optimizer: dict[str, Any]
    memory: dict[str, Any]
    result: dict[str, Any]
    run_log: list[dict[str, Any]]
