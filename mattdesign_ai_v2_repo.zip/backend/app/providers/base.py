from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class ProviderResult:
    content: str
    metadata: dict[str, Any]


class BaseProvider:
    name: str = "base"

    def complete(self, system: str, user: str, temperature: float = 0.2) -> ProviderResult:
        raise NotImplementedError
