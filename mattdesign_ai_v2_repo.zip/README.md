# MattDESIGN.AI v2

A clone-ready starter for an autonomous design system that generates premium websites, assets, brand DNA, copy, memory, and automatic improvements.

## Included
- One-click generation UI
- Multi-agent backend
- JSON memory store
- Critic / optimizer loop
- Free-first architecture
- Optional Ollama / OpenAI / Anthropic adapters

## Repo layout
- `backend/` FastAPI engine
- `frontend/` Next.js control panel
- `prompts/` Copilot / Claude Code instructions
- `docs/` architecture and workflows

## Start locally

### Backend
```bash
cd backend
cp .env.example .env
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

### Frontend
```bash
cd frontend
cp .env.example .env.local
npm install
npm run dev
```

Then open `http://localhost:3000`.

## Default pipeline
Director -> Strategist -> Design DNA -> UI -> Assets -> Copy -> Builder -> Critic -> Optimizer -> Memory

If the critic score is below the threshold, the optimizer runs automatically.

## Note
This repo is intentionally structured so you can plug in better models later without rewriting the whole system.
