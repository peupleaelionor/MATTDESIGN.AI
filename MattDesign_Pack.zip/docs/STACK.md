# Stack MattDesign

## Génération
- ComfyUI : moteur principal de workflows nodaux
- ComfyUI-Manager : gestion des custom nodes
- InvokeAI : interface créative alternative

## Retouche
- Krita AI Diffusion : inpaint, outpaint, itérations précises

## Banque d’assets
- digiKam : gestion photo / tags / collections
- PhotoPrism : indexation et recherche
- darktable : traitement RAW non destructif

## Automatisation
- ImageMagick : conversion, recadrage, batch, normalisation
- rembg : suppression de fond
- SAM 2 : segmentation plus précise
- Upscayl : upscale final

## 3D / motion
- Blender : compositing, mockups, rendu, scènes avancées
