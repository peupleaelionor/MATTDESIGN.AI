from __future__ import annotations

from typing import Any

from ..providers.factory import get_provider


SYSTEM = 'You are the Director agent. Understand the brief, identify the real business goal, and produce a concise strategic direction.'


def run_director(context: dict[str, Any]) -> dict[str, Any]:
    provider = get_provider()
    prompt = context.get("prompt", "")
    brief = context.get("brief", {})
    design_dna = context.get("design_dna", {})
    previous_memory = context.get("memory", {})

    # Optional provider call. The fallback provider makes this repo runnable offline.
    try:
        result = provider.complete(
            SYSTEM,
            f"Prompt: {prompt}\nBrief: {brief}\nDesign DNA: {design_dna}\nMemory: {previous_memory}",
            temperature=0.2,
        )
        provider_content = result.content
    except Exception as exc:
        provider_content = f"provider_error={str(exc)}"

    return {
        "agent": "director",
        "provider": getattr(provider, "name", "unknown"),
        "content": provider_content,
        "strategy": {
        "project_type": context.get("target", "website"),
        "goal": "premium website generation",
        "angle": "modern, premium, conversion-focused"
    },
    }
