# Workflows MattDesign

## 1. Génération simple
Brief -> références -> ComfyUI ou InvokeAI -> variantes -> sélection -> export

## 2. Retouche premium
Image source -> masque -> Krita AI Diffusion -> correction locale -> contrôle qualité -> export

## 3. Détourage
Image source -> rembg ou SAM 2 -> correction masque -> clean export

## 4. Banque d’assets
Import -> indexation -> tags -> collections -> dérivés -> archivage

## 5. Upscale
Sélection finale -> upscale -> vérification des artefacts -> export final

## 6. Lot automatisé
Dossier raw -> script batch -> normalisation -> variantes -> archive
