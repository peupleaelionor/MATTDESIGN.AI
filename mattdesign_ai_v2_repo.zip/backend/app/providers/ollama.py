from __future__ import annotations

from typing import Any

import httpx

from .base import BaseProvider, ProviderResult


class OllamaProvider(BaseProvider):
    name = "ollama"

    def __init__(self, base_url: str, model: str = "llama3.1"):
        self.base_url = base_url.rstrip("/")
        self.model = model

    def complete(self, system: str, user: str, temperature: float = 0.2) -> ProviderResult:
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "stream": False,
            "options": {"temperature": temperature},
        }
        r = httpx.post(f"{self.base_url}/api/chat", json=payload, timeout=120)
        r.raise_for_status()
        data: dict[str, Any] = r.json()
        content = data.get("message", {}).get("content", "")
        return ProviderResult(content=content, metadata={"provider": self.name, "model": self.model})
