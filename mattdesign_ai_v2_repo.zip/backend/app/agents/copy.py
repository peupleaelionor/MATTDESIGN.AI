from __future__ import annotations

from typing import Any

from ..providers.factory import get_provider


SYSTEM = 'You are the Copy agent. Write concise, premium, conversion-oriented website copy.'


def run_copy(context: dict[str, Any]) -> dict[str, Any]:
    provider = get_provider()
    prompt = context.get("prompt", "")
    brief = context.get("brief", {})
    design_dna = context.get("design_dna", {})
    previous_memory = context.get("memory", {})

    # Optional provider call. The fallback provider makes this repo runnable offline.
    try:
        result = provider.complete(
            SYSTEM,
            f"Prompt: {prompt}\nBrief: {brief}\nDesign DNA: {design_dna}\nMemory: {previous_memory}",
            temperature=0.2,
        )
        provider_content = result.content
    except Exception as exc:
        provider_content = f"provider_error={str(exc)}"

    return {
        "agent": "copy",
        "provider": getattr(provider, "name", "unknown"),
        "content": provider_content,
        "copy": {
        "hero_headline": "Build premium sites and assets in one click.",
        "hero_subtitle": "MattDESIGN.AI turns a brief into a polished, high-end website system with design, assets, structure, and memory.",
        "cta_primary": "Generate project",
        "cta_secondary": "Review design",
        "benefits": [
            "Fast generation",
            "Premium layout",
            "Auto-improve loop",
            "Free-first architecture"
        ]
    },
    }
