'use client';

type Props = {
  projects: any[];
};

export function ProjectHistory({ projects }: Props) {
  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-5">
      <div className="mb-3 flex items-center justify-between">
        <h3 className="text-lg font-semibold">Memory</h3>
        <span className="text-xs text-slate-500">{projects.length} saved projects</span>
      </div>

      <div className="grid gap-3">
        {projects.length === 0 && (
          <div className="rounded-2xl border border-dashed border-white/15 bg-black/20 p-4 text-sm text-slate-400">
            No project saved yet.
          </div>
        )}

        {projects.slice(0, 6).map((project, idx) => (
          <div key={`${project.name}-${idx}`} className="rounded-2xl border border-white/10 bg-black/20 p-4">
            <div className="flex items-center justify-between gap-3">
              <div className="font-medium text-white">{project.name}</div>
              <div className="text-xs text-slate-400">{project.score}</div>
            </div>
            <div className="mt-1 text-sm text-slate-400">{project.style}</div>
            <div className="mt-3 flex flex-wrap gap-2">
              {(project.components || []).slice(0, 4).map((item: string) => (
                <span key={item} className="rounded-full border border-white/10 px-3 py-1 text-xs text-slate-300">
                  {item}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
