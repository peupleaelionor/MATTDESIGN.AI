# Copilot Instructions

You are working inside MattDESIGN.AI v2.

Always:
- use modular architecture
- keep components small and reusable
- preserve design system consistency
- prefer TypeScript
- prefer Tailwind CSS
- prefer clean file separation
- add comments only where needed
- think in workflows: generate -> critique -> improve -> save -> reuse

Never:
- create giant files
- mix business logic and UI randomly
- hardcode random styles
- ignore responsive behavior
- skip memory updates
- stop after the first acceptable result

When asked to build a feature:
1. define the data model
2. define the API shape
3. define the UI
4. define the memory impact
5. define the critic criteria
6. define how the optimizer improves it
7. wire everything together cleanly
