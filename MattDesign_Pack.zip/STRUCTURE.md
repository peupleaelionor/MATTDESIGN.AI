# Structure MattDesign

Ce dépôt sert de base à un studio local de design IA.

Le dossier racine sépare :
- les applications
- les assets
- les workflows
- les scripts
- les prompts
- la documentation

Le but est de garder une architecture simple à faire évoluer, tout en restant assez stricte pour un usage de production.
