from __future__ import annotations

from typing import Any

from ..providers.factory import get_provider


SYSTEM = 'You are the Asset Generator agent. Create the full list of visual assets and prompts to produce them consistently.'


def run_assets(context: dict[str, Any]) -> dict[str, Any]:
    provider = get_provider()
    prompt = context.get("prompt", "")
    brief = context.get("brief", {})
    design_dna = context.get("design_dna", {})
    previous_memory = context.get("memory", {})

    # Optional provider call. The fallback provider makes this repo runnable offline.
    try:
        result = provider.complete(
            SYSTEM,
            f"Prompt: {prompt}\nBrief: {brief}\nDesign DNA: {design_dna}\nMemory: {previous_memory}",
            temperature=0.2,
        )
        provider_content = result.content
    except Exception as exc:
        provider_content = f"provider_error={str(exc)}"

    return {
        "agent": "assets",
        "provider": getattr(provider, "name", "unknown"),
        "content": provider_content,
        "assets": [
        {
            "name": "hero-background",
            "format": "webp",
            "purpose": "homepage hero visual",
            "prompt": "dark premium abstract tech background, subtle glow, cinematic lighting, minimal composition, startup-grade"
        },
        {
            "name": "brand-mark",
            "format": "svg",
            "purpose": "logo concept",
            "prompt": "minimal geometric logo, premium, modern, monogram style, clean vector"
        },
        {
            "name": "feature-illustrations",
            "format": "png",
            "purpose": "feature blocks",
            "prompt": "clean modular illustrations, premium UI, subtle gradients, consistent style"
        }
    ],
    }
