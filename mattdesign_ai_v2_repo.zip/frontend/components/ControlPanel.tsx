'use client';

import { useMemo } from 'react';

type Props = {
  prompt: string;
  setPrompt: (value: string) => void;
  projectName: string;
  setProjectName: (value: string) => void;
  style: string;
  setStyle: (value: string) => void;
  target: string;
  setTarget: (value: string) => void;
  oneClick: boolean;
  setOneClick: (value: boolean) => void;
  autoImprove: boolean;
  setAutoImprove: (value: boolean) => void;
  selectedAgents: string[];
  toggleAgent: (agent: string) => void;
  onGenerate: () => void;
  loading: boolean;
};

const agentOrder = [
  'director',
  'strategist',
  'design_dna',
  'ui',
  'assets',
  'copy',
  'builder',
  'critic',
  'optimizer',
  'memory',
];

export function ControlPanel({
  prompt,
  setPrompt,
  projectName,
  setProjectName,
  style,
  setStyle,
  target,
  setTarget,
  oneClick,
  setOneClick,
  autoImprove,
  setAutoImprove,
  selectedAgents,
  toggleAgent,
  onGenerate,
  loading,
}: Props) {
  const enabledCount = useMemo(() => selectedAgents.length, [selectedAgents]);

  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-5 shadow-glow backdrop-blur">
      <div className="mb-4">
        <h1 className="text-2xl font-semibold">MattDESIGN.AI v2</h1>
        <p className="mt-1 text-sm text-slate-300">
          Autonomy + memory + critic loop + one-click generation.
        </p>
      </div>

      <div className="grid gap-3">
        <label className="grid gap-2">
          <span className="text-sm text-slate-300">Project brief</span>
          <textarea
            className="min-h-40 rounded-2xl border border-white/10 bg-black/30 p-4 outline-none ring-0 placeholder:text-slate-500"
            placeholder="Example: premium AI SaaS landing page, dark, minimal, high conversion..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
          />
        </label>

        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          <label className="grid gap-2">
            <span className="text-sm text-slate-300">Project name</span>
            <input
              className="rounded-2xl border border-white/10 bg-black/30 p-3 outline-none"
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
              placeholder="MattDESIGN"
            />
          </label>
          <label className="grid gap-2">
            <span className="text-sm text-slate-300">Style</span>
            <input
              className="rounded-2xl border border-white/10 bg-black/30 p-3 outline-none"
              value={style}
              onChange={(e) => setStyle(e.target.value)}
              placeholder="minimal premium tech"
            />
          </label>
        </div>

        <label className="grid gap-2">
          <span className="text-sm text-slate-300">Target</span>
          <select
            className="rounded-2xl border border-white/10 bg-black/30 p-3 outline-none"
            value={target}
            onChange={(e) => setTarget(e.target.value)}
          >
            <option value="website">Website</option>
            <option value="landing-page">Landing page</option>
            <option value="brand-kit">Brand kit</option>
            <option value="design-system">Design system</option>
          </select>
        </label>

        <div className="grid grid-cols-2 gap-3 text-sm">
          <label className="flex items-center gap-2 rounded-2xl border border-white/10 bg-black/20 p-3">
            <input type="checkbox" checked={oneClick} onChange={(e) => setOneClick(e.target.checked)} />
            One-click mode
          </label>
          <label className="flex items-center gap-2 rounded-2xl border border-white/10 bg-black/20 p-3">
            <input type="checkbox" checked={autoImprove} onChange={(e) => setAutoImprove(e.target.checked)} />
            Auto-improve
          </label>
        </div>

        <div>
          <div className="mb-2 flex items-center justify-between">
            <span className="text-sm text-slate-300">Agents ({enabledCount})</span>
            <span className="text-xs text-slate-500">toggle any agent</span>
          </div>
          <div className="grid grid-cols-2 gap-2 md:grid-cols-3">
            {agentOrder.map((agent) => {
              const active = selectedAgents.includes(agent);
              return (
                <button
                  key={agent}
                  type="button"
                  onClick={() => toggleAgent(agent)}
                  className={`rounded-2xl border px-3 py-2 text-left text-xs transition ${
                    active
                      ? 'border-indigo-400/40 bg-indigo-500/15 text-white'
                      : 'border-white/10 bg-black/20 text-slate-300'
                  }`}
                >
                  {agent}
                </button>
              );
            })}
          </div>
        </div>

        <button
          onClick={onGenerate}
          disabled={loading || !prompt.trim()}
          className="mt-2 rounded-2xl bg-gradient-to-r from-indigo-500 to-violet-500 px-4 py-3 font-medium text-white shadow-glow disabled:cursor-not-allowed disabled:opacity-60"
        >
          {loading ? 'Generating…' : 'Generate in one click'}
        </button>
      </div>
    </div>
  );
}
