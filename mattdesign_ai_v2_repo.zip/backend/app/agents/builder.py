from __future__ import annotations

from typing import Any

from ..providers.factory import get_provider


SYSTEM = 'You are the Builder agent. Turn the project into a practical implementation plan and a deployable site blueprint.'


def run_builder(context: dict[str, Any]) -> dict[str, Any]:
    provider = get_provider()
    prompt = context.get("prompt", "")
    brief = context.get("brief", {})
    design_dna = context.get("design_dna", {})
    previous_memory = context.get("memory", {})

    # Optional provider call. The fallback provider makes this repo runnable offline.
    try:
        result = provider.complete(
            SYSTEM,
            f"Prompt: {prompt}\nBrief: {brief}\nDesign DNA: {design_dna}\nMemory: {previous_memory}",
            temperature=0.2,
        )
        provider_content = result.content
    except Exception as exc:
        provider_content = f"provider_error={str(exc)}"

    return {
        "agent": "builder",
        "provider": getattr(provider, "name", "unknown"),
        "content": provider_content,
        "builder_output": {
        "recommended_stack": ["Next.js", "Tailwind CSS", "FastAPI", "shadcn/ui"],
        "deliverables": ["design system", "components", "assets prompts", "copy", "memory snapshot"],
        "deployment": "local-first or Vercel + API backend"
    },
    }
