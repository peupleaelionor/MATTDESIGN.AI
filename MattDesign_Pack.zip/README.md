# MattDesign

Studio local de design IA, centré sur la génération d’images, la retouche, le détourage, l’upscale, l’organisation d’assets et l’automatisation.

## Pile de base
- ComfyUI
- ComfyUI-Manager
- InvokeAI
- Krita AI Diffusion
- digiKam
- PhotoPrism
- darktable
- ImageMagick
- rembg
- SAM 2
- Upscayl
- Blender

## Objectif
Créer une banque visuelle puissante, un pipeline de production reproductible, et une couche d’orchestration capable de piloter les outils locaux sans dépendre d’API externes.

## Démarrage
1. Lire `PROMPT_MAITRE.md`
2. Utiliser `docs/STACK.md` pour la carte des outils
3. Utiliser `docs/WORKFLOWS.md` pour les pipelines
4. Utiliser `docs/NAMING.md` pour les conventions
5. Brancher Claude ou un autre orchestrateur sur le prompt maître

## Philosophie
- local d’abord
- open source d’abord
- pas d’écrasement des originaux
- assets / masks / variants / exports séparés
- qualité visuelle avant quantité
- batch avant manuel quand c’est possible
- upscale uniquement à la fin

## Structure
Voir `STRUCTURE.md`
